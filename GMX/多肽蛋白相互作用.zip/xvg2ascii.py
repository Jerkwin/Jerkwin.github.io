#!/usr/bin/python

from string import *
from getopt import getopt
from sys import argv

options = {
    "-f": "graph.xvg",
    "-g": "",
    "-x": None,
    "-X": None,
    "-y": None,
    "-Y": None,
    "-e": None,
    "-c": "1",
    "-d": None,
    "-k": "33", # fg color
    "-K": "40", # bg color
    "-p": "*" , # character
    "--square": True,
    "--angles": True
    }

opts, args = getopt( argv[1:], "f:g:x:X:y:Y:e:c:d:k:K:p:s:", ["square","angles"] )
for o, a in opts: options[o] = a    

import struct,fcntl,sys

def termsize():
    return struct.unpack( "HHHH", fcntl.ioctl( sys.stdout.fileno(), 0x5413, struct.pack( "HHHH", 0, 0, 0, 0 ) ) )[:2]

col = int(options["-c"])

class XVG:
    def __init__(self, fn):
        self.title  = ""
        self.xlabel = ""
        self.ylabel = ""
        self.data = []
        fIN = open(fn, 'r')
        line = fIN.readline()
        while line:
            if line[0] in ['#','&']:
                # discard comments
                pass
            elif line[0] == '@':
                # XVG information, should be handling that correctly
                # Though we only need legend labels
                line = line[1:].strip()
                space = line.find(" ")
                keyword = line[:space].strip()
                stuff   = line[space+1:].strip()
                if keyword == "title": self.title = stuff[1:-1]
                if keyword in ["xaxis","yaxis"]:
                    space = stuff.find(" ")
                    if stuff[:space] == "label":
                        if keyword == "xaxis":
                            self.xlabel = stuff[space+1:][1:-1]
                        else:
                            self.ylabel = stuff[space+1:][1:-1]
            elif strip(line):
                # splitting the columns with data and adding them to the list
                # it would be more correct to determine spacing first
                # since this approach will fail when some points are missing
                # hmm, format appears to be '  %12.5e'
                splline = line.split()
                self.data.append(map(float, splline))

            line = fIN.readline()
        fIN.close()

options["-c"] = int( options["-c"] )

plot = XVG( options[ "-f" ] )
if options["-g"]:
    plot2 = XVG( options["-g"] )
    if not options["-d"]:
        options["-d"] = options["-c"]
    else:
        options["-d"] = int( options["-d"] )
    print options["-f"] + "//" + plot.title + ": " + plot.ylabel + " ~ " + options["-g"] + "//" + plot2.title + ": " + plot2.ylabel + " (terminal size: %dx%d)" % termsize()
else:
    print plot.title + ": " + plot.ylabel + " ~ " + plot.xlabel + " (terminal size: %dx%d)" % termsize()

if not plot.data:
    print "No data in file!"
    exit
    
if options["-g"]:
    xmin = xmax =  plot.data[0][ options["-c"] ]
    ymin = ymax = plot2.data[0][ options["-d"] ]
    for x in plot.data:
        if x[ options["-c"] ] < xmin: xmin = x[ options["-c"] ]
        if x[ options["-c"] ] > xmax: xmax = x[ options["-c"] ]
    for y in plot2.data:
        if y[ options["-d"] ] < ymin: ymin = y[ options["-d"] ]
        if y[ options["-d"] ] > ymax: ymax = y[ options["-d"] ]
else:
    xmin = xmax = plot.data[0][0]
    ymin = ymax = plot.data[0][ options["-c"] ]
    for x in plot.data:
        if x[0] < xmin: xmin = x[0]
        if x[0] > xmax: xmax = x[0]
    for y in plot.data:
        if y[ options["-c"] ] < ymin: ymin = y[ options["-c"] ]
        if y[ options["-c"] ] > ymax: ymax = y[ options["-c"] ]

if not options["--angles"]:
    options["-x"] = -180
    options["-X"] =  180
    options["-y"] = -180
    options["-Y"] =  180
    options["--square"] = False
    
if options[ "-x" ]: # and float( options[ "-x" ] ) > xmin: 
    xmin = float( options[ "-x" ] )
else:
   options[ "-x" ] = xmin

if options[ "-X" ]: # and float( options[ "-X" ] ) < xmax: 
    xmax = float( options[ "-X" ] )
else:
   options[ "-X" ] = xmax

if options[ "-y" ]: # and float( options[ "-y" ] ) > ymin: 
    ymin = float( options[ "-y" ] )
else:
   options[ "-y" ] = ymin

if options[ "-Y" ]: # and float( options[ "-Y" ] ) < ymax: 
    ymax = float( options[ "-Y" ] )
else:
   options[ "-y" ] = ymax

if not options["--square"]:
    xmax = ymax = max( xmax, ymax )
    xmin = ymin = min( xmin, ymin )

xrange = xmax - xmin
yrange = ymax - ymin

scaled = []

if options["-g"]:
    for i in range(min( len(plot.data), len(plot2.data) )):
        x, y = plot.data[i][1], plot2.data[i][1]
        if x <= xmax and x >= xmin and y <= ymax and y >= ymin:
            scaled.append( ( ( x - xmin ) / xrange, ( y - ymin ) / yrange ) )                   
else:
    for i in plot.data:
	x, y = i[0], i[ options["-c"] ]
        if x <= xmax and x >= xmin and y <= ymax and y >= ymin:
            scaled.append( ( ( x - xmin ) / xrange, ( y - ymin ) / yrange ) )

ybins, xbins = termsize()
ybins -= 9
xbins -= 2
if not options["--square"] and 4*xbins != 2*ybins:
    if 2*ybins < 4*xbins:
        xbins = 4*ybins/2
    else:
        ybins = 2*xbins/4

out = []
for i in range(ybins+1):
    out.append([])
    for j in range(xbins+1): out[i].append(0)

mx = 0
for x, y in scaled:
    xbin, ybin = int( x*xbins), int( y*ybins )
    out[ ybin ][ xbin ] += 1
    if out[ ybin ][ xbin ] > mx:
        mx = out[ ybin ][ xbin ]
print "Maximum density = ", mx

colours = [ 31, 33, 32, 36, 34, 35 ]
 
def trans( a ):
    if a > 0:
        return "\033[%dm%s" % (colours[ int( 5. * a / mx + 0.5 ) ], options["-p"] )
    else:
        return " "

out.reverse()

xminstr, xmaxstr = "%.5f" % xmin, "%.5f" % xmax
yminstr, ymaxstr = "%.5f" % ymin, "%.5f" % ymax

print ymaxstr
for i in out:
    print "|"+ "\033[1;33;40m" + join( map( trans, i ), "" ) + "\033[0m"
print yminstr
print "|"+(xbins)*"_"

print " |" + (xbins-2)*" " + "|"
print " " + xminstr + (xbins-len(xminstr)-len(xmaxstr))*" " + xmaxstr




