 molecular dynamics 
 $cntrl
  irest  = 0, ntx    = 1,
  ntb    = 2, ntp    = 1,
  nstlim = 5,
  dt     = 0.001,
  ntt    = 1,
  iwrap  = 1,
  ntpr   = 1000,
  nsnb   = 5,
  temp0  = 300.,
  cut    = 7.5,
  scee   = 1.2,
  ntf    = 2,
  ntc    = 2,
 $end

