/* HEATfitting.c
 * = = = = = Po-chia Chen, Georg-August University Goettingen = = = =
 * = = = = = Distributed to ResearchGate on 23.03.2015 = = = = =
 * = The author requests that principles free software (www.fsf.org)
 *  be applied to this code, but do not attach a GPL-like license.
 *
 * Notes:
 * - nslq-cylfit.c requires GNU SCientific Library for you C compiler.
 * An example compile command looks like this:
 *
 * gcc HEATfitting.c -L/opt/local/lib -lgsl -lgslcblas -Wall -I/opt/local/include
 * gcc HEATfitting.c -lgsl -lgslcblas -I/share/apps/gsl/gsl-1.16-intel-13.1.0-mkl/include -L/share/apps/gsl/gsl-1.16-intel-13.1.0-mkl/lib
 
 * This tool computes the fit of an ideal helix over all atoms
 * of an .xyz file. It will take, for example:
 *  - CA-atoms of a helix.
 *  - center-of-masses (origin intent of code, hence HEAT-repeats)
 *
 * Because a single ideal helix is fitted, bending and kinked helices
 * can produce multistable solutions. There are several publications, IIRC,
 * attesting to this. Hence, other tools that measure local helical properties
 * will be more appropriate for twisty things.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>

#define TRUE 1
#define FALSE 0
#define N 40
#define STRLEN 256

#define MAX_ITER 500

#define TRUE 1
#define FALSE 0

#define PI 3.14159265358979323846
#define GSL_FIT(i) gsl_vector_get(s->x, i)
#define GSL_ERR(i) sqrt(gsl_matrix_get(covar,i,i))


/* myvec.h */
#define DIM 3

#ifndef _MYVEC_H
#define _MYVEC_H

typedef double dvec[3];

static void clear_dvec(dvec x)
{
    x[0]=0;
    x[1]=0;
    x[2]=0;
}

static void copy_dvec(dvec a, dvec b)
{
    b[0]=a[0];
    b[1]=a[1];
    b[2]=a[2];
}

static double dvec_norm2(dvec x)
{
    return (x[0]*x[0] + x[1]*x[1] + x[2]*x[2]);
}

static double dvec_norm(dvec x)
{
    return sqrt(dvec_norm2(x));
}

static double dvec_iprod(dvec a, dvec b)
{
    return (a[0]*b[0] + a[1]*b[1] + a[2]*b[2]);
}

static void dvec_cprod(const dvec a, const dvec b, dvec c)
{
        c[0] = a[1]*b[2]-a[2]*b[1];
        c[1] = a[2]*b[0]-a[0]*b[2];
        c[2] = a[0]*b[1]-a[1]*b[0];
}

static void dvec_sub(const dvec a, const dvec b, dvec c)
{
    double x, y, z;

    x = a[0]-b[0];
    y = a[1]-b[1];
    z = a[2]-b[2];

    c[0] = x;
    c[1] = y;
    c[2] = z;
}

static void dvec_add(const dvec a, const dvec b, dvec c)
{
    double x, y, z;

    x = a[0]+b[0];
    y = a[1]+b[1];
    z = a[2]+b[2];

    c[0] = x;
    c[1] = y;
    c[2] = z;
}

static void dvec_inc(dvec a, const dvec b)
{
    a[0]=a[0]+b[0];
    a[1]=a[1]+b[1];
    a[2]=a[2]+b[2];
}

static void dvec_scale(const double r, const dvec a, dvec b)
{
    b[0]=r*a[0];
    b[1]=r*a[1];
    b[2]=r*a[2];
}

static void dvec_unit(dvec a, dvec b)
{
    double r = dvec_norm(a);
    dvec_scale(1.0/r, a, b);
}

static void dvec_com(int xsize, dvec x[], dvec xcm)
{
    int i;

    clear_dvec(xcm);
    for (i=0; i<xsize; i++)
    {
        dvec_inc(xcm, x[i]);
    }
    for (i=0;i<DIM;i++)
    {
        xcm[i] /= (xsize);
    }

}

static double dvec_avrad(int xsize, dvec x[], dvec rcom)
{
    int i;
    dvec a;
    double sum=0;
    for (i=0; i<xsize; i++)
    {
        dvec_sub(x[i], rcom, a);
        sum += dvec_norm(a);
    }
    return sum/xsize;
}

#endif

void
debug_print_fithelix(FILE *fp, int npts, dvec r0, dvec a, double rad,
                     double rpr, double tpr, double h0, double t0)
{
    dvec vtmp, v, w;
    double turn, rise;
    unsigned int i;

    /* generate basis vectors v and w */
    dvec_scale(1.0/dvec_norm(r0), r0, v);
    dvec_cprod(a, v, w);

    fprintf(fp,"%d\n", npts);
    fprintf(fp,"Fitted helix\n");

    for (i=0; i<npts; i++)
    {
        turn=tpr*i+t0;
        rise=rpr*i+h0;
        vtmp[0]=r0[0] + rise*a[0] + rad * (v[0]*cos(turn) + w[0]*sin(turn));
        vtmp[1]=r0[1] + rise*a[1] + rad * (v[1]*cos(turn) + w[1]*sin(turn));
        vtmp[2]=r0[2] + rise*a[2] + rad * (v[2]*cos(turn) + w[2]*sin(turn));
        fprintf(fp, "COM %g %g %g\n", vtmp[0], vtmp[1], vtmp[2]);
    }
}

int
main (int argc, char *argv[])
{
  int i, j;
  //Decide on solver algorithm here.
  const gsl_multifit_fdfsolver_type *T = gsl_multifit_fdfsolver_lmsder;

  int nx, nfr, nalloc=100, xallocsize;
  dvec **x;
  double *sigma;

  /* File IO */
  FILE *fp1, *fp2;
  size_t bytes=0;
  int bFirst=1, bPrintHelices=0;
  size_t len=0;
  char *line = NULL;
  char dump[STRLEN];
  char infn[STRLEN], outfn[STRLEN], fitfn[STRLEN];
  //char plotfn1[STRLEN]="debug-helix.dat";
  //char plotfn2[STRLEN]="debug-cyl.dat";

  /* Time-keeping variables */
  //clock_t tbeg, tcheck, tend;
  //double telapsed;

    /* Parameters */
    dvec r0, a;
    double rad, avrise, avturn, rise0, turn0;

    if( argc < 3)
    {
        fprintf(stdout, "Usage: ./program helix.xyz out.dat [fit-helices.xyz]\n");
        return 0;
    }
    strcpy(infn, argv[1]);
    strcpy(outfn, argv[2]);
    if (argc == 4)
    {
        bPrintHelices=TRUE;
        strcpy(fitfn, argv[3]);
    }

    fp1=fopen(infn, "r");
    if (fp1==NULL)
    {
        fprintf(stderr,"Cannot read file %s!\n", infn);
        return 127;
    }
    fprintf(stdout,"File %s opened.\n", infn);

    /*Preallocate some memory. */
    //snew(x,nalloc);
    x=malloc(sizeof(*x)*nalloc);
    xallocsize=nalloc;

    nfr=0;

    while(getline(&line, &len, fp1) != -1 )
    {
        j = atoi(line);
        if (bFirst && j != 0)
        {
            nx=j;
            fprintf(stdout,"File report %i centers in helix.\n", nx);
            /* Now we can allocate some data. */
            bFirst=FALSE;
        }

        if (j != nx || j==0)
        {
            fprintf(stderr,"Line: %s\n", line);
            fprintf(stderr,"nfr = %d, j = %d, nx = %d\n", nfr, j, nx);
            fprintf(stderr,"Invalid format detected! Please check your .xyz formatting!\n");
            return 125;
        }

        bytes=getline(&line, &len, fp1); //XYZ title.

        /*Allocate data for this frame*/
        x[nfr]=malloc(sizeof(**x)*nx);

        for(i=0; i<nx; i++)
        {
            bytes=getline(&line, &len, fp1); //Data entry.
            sscanf(line, "%s %lf %lf %lf\n", dump, &x[nfr][i][0], &x[nfr][i][1], &x[nfr][i][2]);
            //fprintf(stderr,"%d: %s\n", i, dump);
        }

        nfr++;
        if (nfr == xallocsize)
        {
            xallocsize+=nalloc;
            x=realloc(x, sizeof(*x)*xallocsize);
        }

        if (nfr % 500 == 0)
            fprintf(stdout,"Have read %d frames...\n", nfr);

    }
    fclose(fp1);

    fprintf(stdout,"= = Initial read complete. = =\n");

    /*Prepare starting guesses and weights.*/
    sigma=malloc(sizeof(*sigma)*nx);
    for (i=0;i<nx;i++)
        sigma[i]=0.1;

    /* Begin fitting process. */
    fp1=fopen(outfn,"w");
    if (bPrintHelices)
        fp2=fopen(fitfn,"w");

    fprintf(fp1,"#frame rise/atom turn/atom radius helical-axes\n");
    for(j=0; j<nfr; j++)
    {
        /* Get estimate of a */
        //calc_helaxis_kahn(nx, x, a);
        dvec_sub(x[j][nx-1], x[j][0], a);
        dvec_unit(a, a);

        /* Using fixed a, get estimate of r0 and rad */
        fit_circle_fixed_a(T, nx, x[j], sigma, a, r0, &rad, FALSE);

        /* Optimise r0, a, and rad together */
        fit_cylinder_all(T, nx, x[j], sigma, a, r0, &rad, FALSE);

        calc_avg_rise_turn_fixed_cylinder(nx, x[j], a, r0, &rad,
                                     &avrise, &avturn, &rise0, &turn0);

        /*fit_helix_simple(T, nx, x[j], sigma, a, r0, &rad,
                     &avrise, &avturn, &rise0, &turn0,
                     FALSE);*/

        fprintf(fp1,"%5u %8g %8g %8g %8g %8g %8g\n", j, avrise, avturn, rad, a[0], a[1], a[2]);

        if(bPrintHelices)
        {
            debug_print_fithelix(fp2, nx, r0, a, rad, avrise, avturn, rise0, turn0);
        }
    }
    fclose(fp1);
    if (bPrintHelices)
        fclose(fp2);

    fprintf(stdout,"= = Fitting complete. = =\n");

    for(j=0; j<nfr;j++)
    {
        free(x[j]);
    }
    free(x);
    free(sigma);

    return 0;
}


/* cylfit.c -- model functions for exponential + background
 * The deal here is to fit seven parameters simultaneously:
 * - a, the direction of the cylinder,
 * - the center of the cylinder r0 defined to be perpendicular to a
 * - rad, the size of the cylinder.
 *
 * The 7-dimensional gsl_vector should contain the following:
 * - r0
 * - a
 * - rad.
 *
 * Trere is an additional circle fit beforehand to estimate the
 * initial r0, rad given fixed a.
 * Here, there is a 4-dimensional gsl_vector:
 * - r0
 * - rad
 */


struct nlsq_datablock {
  size_t n;
  dvec   * x;
  double * sigma;
  dvec a;
};

static void vec_cart_to_polar(dvec a, double *th, double *ph)
{
    if (a[0] != 0 || a[1] != 0 )
        *th= atan2(a[1], a[0]);
    else
        *th=0; //Grab exception.
    *ph= asin( a[2] );
}

static void r0a_cart_to_polar(dvec r0, dvec a, double *th, double *ph, double *nu, double *r0n)
{
    dvec ascnode;

    *r0n=dvec_norm(r0);

    if (a[0] != 0 || a[1] != 0 )
        *th= atan2(a[1], a[0]);
    else
        *th=0; //Grab exception.
    *ph= asin( a[2] ) ;

    ascnode[0]=-1*sin(*th);
    ascnode[1]=cos(*th);
    ascnode[2]=0;

    *nu= acos( dvec_iprod(ascnode, r0) / *r0n ) ;
    if (r0[2] < 0)
    {
    	*nu=2*PI-*nu;
    }

/*    fprintf(stderr,"%s %g %g %g\n",  "a", a[0], a[1], a[2]);
    fprintf(stderr,"%s %g %g %g\n", "r0", r0[0], r0[1], r0[2]);
    fprintf(stderr,"%s %g\n", "r.a", dvec_iprod(r0,a));
    fprintf(stderr,"%s %g\n", "th", *th);
    fprintf(stderr,"%s %g\n", "ph", *ph);
    fprintf(stderr,"%s %g\n", "nu", *nu);
    fprintf(stderr,"%s %g\n", "r0n", *r0n);    */
}

static void r0a_polar_to_cart(double th, double ph, double nu, double r0n, dvec r0, dvec a)
{
  double sth = sin(th), cth = cos(th);
  double sph = sin(ph), cph = cos(ph);
  double snu = sin(nu), cnu = cos(nu);

  r0[0] = r0n*( -1*cth*snu*sph - sth*cnu);
  r0[1] = r0n*( -1*sth*snu*sph + cth*cnu);
  r0[2] = r0n*(        snu*cph          );

   a[0] = cth*cph;
   a[1] = sth*cph;
   a[2] =     sph;

}

static void r0a_get_polar_derivatives(double th, double ph, double nu, double r0n,
          dvec dr0dth, dvec dr0dph, dvec dr0dnu, dvec dr0dr0n,
          dvec dadth, dvec dadph)
{
    double sth = sin(th), cth = cos(th);
    double sph = sin(ph), cph = cos(ph);
    double snu = sin(nu), cnu = cos(nu);

    dr0dth[0] = r0n*(    sth*snu*sph - cth*cnu );
    dr0dth[1] = r0n*( -1*cth*snu*sph - sth*cnu );
    dr0dth[2] = r0n*(        cnu*cph           );

    dr0dph[0] = r0n*( -1*cth*snu*cph );
    dr0dph[1] = r0n*( -1*sth*snu*cph );
    dr0dph[2] = r0n*( -1*    snu*sph );

    dr0dnu[0] = r0n*( -1*cth*cnu*sph + sth*snu );
    dr0dnu[1] = r0n*( -1*sth*cnu*sph - cth*snu );
    dr0dnu[2] = 0;

    dr0dr0n[0] =      -1*cth*snu*sph - sth*cnu  ;
    dr0dr0n[1] =      -1*sth*snu*sph + cth*cnu  ;
    dr0dr0n[2] =             snu*cph            ;

    dadth[0] = -1*sth*cph;
    dadth[1] =    cth*cph;
    dadth[2] =  0;

    dadph[0] = -1*cth*sph;
    dadph[1] = -1*sth*sph;
    dadph[2] =        cph;

}

/* Model of perpendiclar distance to axis a
 * di = xi - r0 - (xi.a) a
 */
static void r0a_calc_perp_dist(dvec xi, dvec r0, dvec a, dvec d, double *dnorm, double *xdota)
{
      *xdota = dvec_iprod(xi, a);

      d[0] = xi[0] - r0[0] - *xdota * a[0];
      d[1] = xi[1] - r0[1] - *xdota * a[1];
      d[2] = xi[2] - r0[2] - *xdota * a[2];

      *dnorm = dvec_norm(d);
}

// This circle is already projected onto the plane passing through the origin,
// We can effectly fit a spherical cartesian distance.
int
expb_fcircar (const gsl_vector * v, void *data,
        gsl_vector * f)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma; //Relative weight.
  dvec a;
  dvec r0, d;
  double dnorm, xdota, th, ph, nu, r0n;

  copy_dvec( ((struct nlsq_datablock *)data)->a, a);
  vec_cart_to_polar(a, &th, &ph);

  nu = gsl_vector_get (v, 0);
  r0n = gsl_vector_get (v, 1);
  double rad = gsl_vector_get (v, 2);

  r0a_polar_to_cart(th, ph, nu, r0n, r0, d); //d is a dummy variable, we already know a.

  size_t i;
  double Ui;

  for (i=0; i<n; i++)
    {
      /* Model Ui = (|di| - R ) ^2 / sigma */
      /* di = xi - r0 */
      //dvec_sub(x[i], r0, d);
      //dnorm = dvec_norm(d);

      r0a_calc_perp_dist(x[i], r0, a, d, &dnorm, &xdota);
      Ui = (rad - dnorm)/sigma[i];
      gsl_vector_set (f, i, Ui);
    }

  return GSL_SUCCESS;
}

int
expb_dfcircar (const gsl_vector * v, void *data,
         gsl_matrix * J)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma;
  dvec a;
  dvec r0, d;
  double dnorm, xdota, th, ph, nu, r0n;

  copy_dvec( ((struct nlsq_datablock *)data)->a, a);
  vec_cart_to_polar(a, &th, &ph);

  nu = gsl_vector_get (v, 0);
  r0n = gsl_vector_get (v, 1);
  //double rad = gsl_vector_get (v, 2);

  r0a_polar_to_cart(th, ph, nu, r0n, r0, d); //d is a dummy variable, we already know a.

  dvec dr0dth, dr0dph, dr0dnu, dr0dr0n, dadth, dadph;
  //Assign static derivatives.
  r0a_get_polar_derivatives(th, ph, nu, r0n,
          dr0dth, dr0dph, dr0dnu, dr0dr0n,
          dadth,  dadph);

  size_t i;
  double fac1, Jij;

  for (i=0; i<n; i++)
    {
      /* Jacobian J(i,j) = dUi / dej,
       * dUi / dej = 2( |d|-R ) * d/dej( |d|-R )
       */

      //First calcualte |di - R |
      //dvec_sub(x[i], r0, d);
      //dnorm=dvec_norm(d);

      r0a_calc_perp_dist(x[i], r0, a, d, &dnorm, &xdota);

      fac1 = 1.0/sigma[i];

      //Now set each Jacobian.
      /* nu */
      Jij = fac1/dnorm*(d[0]*dr0dnu[0] +
                        d[1]*dr0dnu[1] +
		        d[2]*dr0dnu[2] );
      gsl_matrix_set (J, i, 0, Jij );

      /* r0 */
      Jij = fac1/dnorm*(d[0]*dr0dr0n[0] +
                        d[1]*dr0dr0n[1] +
		        d[2]*dr0dr0n[2] );
      gsl_matrix_set (J, i, 1, Jij );

      /* rad */
      Jij = fac1;
      gsl_matrix_set (J, i, 2, Jij );
    }
  return GSL_SUCCESS;
}

int
expb_fdfcircar (const gsl_vector * x, void *data,
          gsl_vector * f, gsl_matrix * J)
{
  expb_fcircar (x, data, f);
  expb_dfcircar (x, data, J);

  return GSL_SUCCESS;
}

/* = = = = = Here are the solvers in angular representation = = = = = */
/* The model for the full helix is as follows
 *
 * Xh  = r0 + a (p0+p*t) + r( v cos(w*t+w0) + w sin(w*t+w0)
 *
 * v = ^r0.
 * w = ^a x ^r0.
 */

/* Our model is as follows:
 *
 * U = ( R - |d| / sigma ) ^2
 *
 * dUi/dej = 2(|R|-d)/sigma * ( d/de(|d|) - d/dej(R))
 * = 2(R-|d|)/s * ( 0.5/|d|*(2*dx*d/dej(dx)+2*dy*d/dej(dy)+2*dz*d/dej(dz)) - dR/dej )
 * = 2(R-|d|)/s * ( ( dx*ddx/dej +... ) /|d|) - dR/dej )
 *
 * We will store dx, dy, dz, |d|
 *
 *
 */

int
expb_fcylr (const gsl_vector * v, void *data,
        gsl_vector * f)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma; //Relative weight.
  size_t i;

  double th  = gsl_vector_get (v, 0);
  double ph  = gsl_vector_get (v, 1);
  double nu  = gsl_vector_get (v, 2);
  double r0n = gsl_vector_get (v, 3);
  double rad = gsl_vector_get (v, 4);

  double Ui, dnorm, xdota;
  dvec r0, a, d;
  //Convert Polar parameters to Cartesians representation.
  r0a_polar_to_cart(th, ph, nu, r0n, r0, a);

  for (i=0; i<n; i++)
    {
      /* Model Ui = (|di| - R)^2/s */
      r0a_calc_perp_dist(x[i], r0, a, d, &dnorm, &xdota);
      Ui = (rad - dnorm)/sigma[i];
      gsl_vector_set (f, i, Ui);
    }

  return GSL_SUCCESS;
}

int
expb_dfcylr (const gsl_vector * v, void *data,
         gsl_matrix * J)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma;
  size_t i;

  double th  = gsl_vector_get (v, 0);
  double ph  = gsl_vector_get (v, 1);
  double nu  = gsl_vector_get (v, 2);
  double r0n = gsl_vector_get (v, 3);
  //double rad = gsl_vector_get (v, 4);

  dvec r0, a;
  //Convert Polar parameters to Cartesians representation.
  r0a_polar_to_cart(th, ph, nu, r0n, r0, a);

  dvec dr0dth, dr0dph, dr0dnu, dr0dr0n, dadth, dadph;
  //Assign static derivatives.
  r0a_get_polar_derivatives(th, ph, nu, r0n,
          dr0dth, dr0dph, dr0dnu, dr0dr0n,
          dadth,  dadph);

  double dnorm, xdota, fac1, Jij;
  dvec d;

  for (i=0; i<n; i++)
    {
      /* Jacobian J(i,j) = dUi / dej,
       * U = (|d|-R)^2/s
       * dUi / dej = 2( |d|-R )/2 * d/dej( |d|-R )
       */

      //First calculate |di - R |
      r0a_calc_perp_dist(x[i], r0, a, d, &dnorm, &xdota);

      fac1 = 1/sigma[i];

      //Now set each Jacobian.
      /* theta */
      Jij = fac1/dnorm*(d[0]*(dr0dth[0] + xdota*dadth[0]) +
                        d[1]*(dr0dth[1] + xdota*dadth[1]) +
		        d[2]*(dr0dth[2] + xdota*dadth[2]) );
      gsl_matrix_set (J, i, 0, Jij );

      /* phi */
      Jij = fac1/dnorm*(d[0]*(dr0dph[0] + xdota*dadph[0]) +
                        d[1]*(dr0dph[1] + xdota*dadph[1]) +
		        d[2]*(dr0dph[2] + xdota*dadph[2]) );
      gsl_matrix_set (J, i, 1, Jij );

      /* nu */
      Jij = fac1/dnorm*(d[0]*dr0dnu[0] +
                        d[1]*dr0dnu[1] +
		        d[2]*dr0dnu[2] );
      gsl_matrix_set (J, i, 2, Jij );

      /* r0 */
      Jij = fac1/dnorm*(d[0]*dr0dr0n[0] +
                        d[1]*dr0dr0n[1] +
		        d[2]*dr0dr0n[2] );
      gsl_matrix_set (J, i, 3, Jij );

      /* rad */
      Jij = fac1;
      gsl_matrix_set (J, i, 4, Jij );
    }

  return GSL_SUCCESS;
}

int
expb_fdfcylr (const gsl_vector * x, void *data,
          gsl_vector * f, gsl_matrix * J)
{
  expb_fcylr  (x, data, f);
  expb_dfcylr (x, data, J);

  return GSL_SUCCESS;
}

/* Here are the functions for the helix.
 *
 * We will use the parametric model as recorded by HELFIT with minor modificaitons:
 *
 * xh = |r| ^r + P*om/(2pi) ^a + rad*cos(om+om0) ^v + rad*sin(om+om0) ^w
 *
 * P is now directly the pitch of the helix.
 * om0 determines the turn angle when the helix intersects the r0 plane.
 *
 * v is set in the direction of r0, as below.
 * The other parameters are associatd with hte fitting cylinder.
 *
 */

/* Define v to be in the direction of r0. */
static void r0a_calc_vw(dvec r0, dvec a, dvec v, dvec w)
{
     dvec_unit(r0, v);
     dvec_cprod(a, v, w);
}

static void r0avw_polar_to_cart(double th, double ph, double nu, double r0n, double rad,
                                dvec r0, dvec a, dvec v, dvec w)
{
    double sth = sin(th), cth = cos(th);
    double sph = sin(ph), cph = cos(ph);
    double snu = sin(nu), cnu = cos(nu);

    v[0] = ( -1*cth*snu*sph - sth*cnu);
    v[1] = ( -1*sth*snu*sph + cth*cnu);
    v[2] = (        snu*cph          );

    w[0] = ( -1*cth*cnu*sph + sth*snu);
    w[1] = ( -1*sth*cnu*sph - cth*snu);
    w[2] = (        cnu*cph          );

    dvec_scale(r0n, v, r0);

    a[0] = cth*cph;
    a[1] = sth*cph;
    a[2] =     sph;

}

/* The return arguments are optional if they are not needed. */
static void calc_cylinder_rise_turn(dvec xi, dvec r0, dvec a, dvec v, dvec w,
                                    double *h, double *om, double *rad)
{
    dvec xa;
    double hloc;

    hloc=dvec_iprod(xi, a);//Current rise above plane
    if (h)
        *h=hloc;
    dvec_scale(hloc, a, xa); //Projection of x[i] onto the helical axis.
    dvec_add(r0, xa, xa);   //Cartesian position of this projection.
    dvec_sub(xi, xa, xa);  //Vector of perpendicular distance d.
    if(om)
        *om = atan2( dvec_iprod(xa, w) , dvec_iprod(xa, v) ); //From -pi to pi

    if(rad)
        *rad=dvec_norm(xa);

}

static void calc_helix_pos(dvec r0, dvec a, dvec v, dvec w, double rad, double rise, double turn,
                           dvec xh)
{
    xh[0]=r0[0]+rise*a[0]+rad*cos(turn)*v[0]+rad*sin(turn)*w[0];
    xh[1]=r0[1]+rise*a[1]+rad*cos(turn)*v[1]+rad*sin(turn)*w[1];
    xh[2]=r0[2]+rise*a[2]+rad*cos(turn)*v[2]+rad*sin(turn)*w[2];
}

/* Assuming the above parametrisation model of the helix. */
static void find_min_dist_from_helix(dvec xi, dvec r0, dvec a, dvec v, dvec w, double rad, double P, double om0,
                                    double *om, dvec d)
{
    double hloc, omloc;

    calc_cylinder_rise_turn(xi, r0, a, v,  w, &hloc, &omloc, NULL);

    /* Solve which om gives the minimum distance to omloc and hloc.
     *
     * h = P/(2pi)* (om - om0 )
     */

    /* Not finished */
}

/* The helix fitting functions are not finished */
/* int
expb_fhelr (const gsl_vector * v, void *data,
        gsl_vector * f)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma; //Relative weight.
  size_t i;

  double th   = gsl_vector_get (v, 0);
  double ph   = gsl_vector_get (v, 1);
  double nu   = gsl_vector_get (v, 2);
  double r0n  = gsl_vector_get (v, 3);
  double rad  = gsl_vector_get (v, 4);
  double pt   = gsl_vector_get (v, 5);
  double t0   = gsl_vector_get (v, 6);

  return GSL_FAILURE;
}

int
expb_dfhelr (const gsl_vector * v, void *data,
         gsl_matrix * J)
{
  size_t n = ((struct nlsq_datablock *)data)->n;
  dvec * x = ((struct nlsq_datablock *)data)->x;
  double *sigma = ((struct nlsq_datablock *) data)->sigma;
  size_t i;

  return GSL_FAILURE;
}

int
expb_fdfhelr (const gsl_vector * x, void *data,
          gsl_vector * f, gsl_matrix * J)
{
  expb_fhelr  (x, data, f);
  expb_dfhelr (x, data, J);

  return GSL_FAILURE;
}*/

/* = = = =
 * This section is for the surrounding functions.
 * = = = =
 */

static void report_gsl_solver_outcome1(gsl_multifit_fdfsolver *s, gsl_matrix *covar, int npts, int nparams)
{
    double chi = gsl_blas_dnrm2(s->f);
    double dof = npts - nparams;
    double c = GSL_MAX_DBL(1, chi / sqrt(dof));

    printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);

    fprintf(stdout, "%s = %.5f +/- %.5f\n", "nu", GSL_FIT(0), c*GSL_ERR(0));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "|r0|", GSL_FIT(1), c*GSL_ERR(1));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "radius", GSL_FIT(2), c*GSL_ERR(2));

    /*
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0.x", GSL_FIT(0), c*GSL_ERR(0));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0.y", GSL_FIT(1), c*GSL_ERR(1));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0.z", GSL_FIT(2), c*GSL_ERR(2));
   	fprintf(stdout, "%s = %.5f +/- %.5f\n", "radius", GSL_FIT(3), c*GSL_ERR(3));
    */

}

static void report_gsl_solver_outcome2(gsl_multifit_fdfsolver *s, gsl_matrix *covar, int npts, int nparams)
{
    double chi = gsl_blas_dnrm2(s->f);
    double dof = npts - nparams;
    double c = GSL_MAX_DBL(1, chi / sqrt(dof));

    printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);

    fprintf(stdout, "%s = %.5f +/- %.5f\n", "theta", GSL_FIT(0), c*GSL_ERR(0));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "phi", GSL_FIT(1), c*GSL_ERR(1));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "nu", GSL_FIT(2), c*GSL_ERR(2));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "|r0|", GSL_FIT(3), c*GSL_ERR(3));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "radius", GSL_FIT(4), c*GSL_ERR(4));

    /*
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0[0]", GSL_FIT(0), c*GSL_ERR(0));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0[1]", GSL_FIT(1), c*GSL_ERR(1));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "r0[2]", GSL_FIT(2), c*GSL_ERR(2));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "a[0]", GSL_FIT(3), c*GSL_ERR(3));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "a[1]", GSL_FIT(4), c*GSL_ERR(4));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "a[2]", GSL_FIT(5), c*GSL_ERR(5));
    fprintf(stdout, "%s = %.5f +/- %.5f\n", "radius", GSL_FIT(6), c*GSL_ERR(6));
    */

}

void
print_state1 (size_t iter, gsl_multifit_fdfsolver * s)
{
    fprintf(stdout,"iter: %3u nu = %12.8f, r0 = %12.8f, rad = %12.8f "
          "|f(x)| = %g\n",
          (unsigned int) iter,
		  GSL_FIT(0),
		  GSL_FIT(1),
	 	  GSL_FIT(2),
          gsl_blas_dnrm2(s->f) );

    /*
    fprintf(stdout,"iter: %3u r0 = % 15.8f % 15.8f % 15.8f, rad = % 15.9f "
          "|f(x)| = %g\n",
          (unsigned int) iter,
				GSL_FIT(0),
				GSL_FIT(1),
			    GSL_FIT(2),
			    GSL_FIT(3),
          		gsl_blas_dnrm2(s->f) );
	*/
}

void
print_state2 (size_t iter, gsl_multifit_fdfsolver * s)
{

    fprintf(stdout,"iter: %3u theta = %12.8f, phi = %12.8f, nu = %12.8f, r0 = %12.8f, rad = %12.8f "
          "|f(x)| = %g\n",
          (unsigned int) iter,
          GSL_FIT(0),
          GSL_FIT(1),
          GSL_FIT(2),
          GSL_FIT(3),
          GSL_FIT(4),
          gsl_blas_dnrm2(s->f) );

    /*
    fprintf(stdout,"iter: %3u r0= %12.8f %12.8f %12.8f, a0= %12.8f %12.8f %12.8f, rad = %12.8f "
          "|f(x)| = %g\n",
          (unsigned int) iter,
        GSL_FIT(0),
	  GSL_FIT(1),
	  GSL_FIT(2),
	  GSL_FIT(3),
 	  GSL_FIT(4),
 	  GSL_FIT(5),
   	  GSL_FIT(6),
          gsl_blas_dnrm2(s->f) );
    */

}

void
debug_print_fitcircle(char * fn, int npts, dvec r0, dvec a, double rad)
{
    FILE *fp;
    dvec vtmp, v, w;
    double ang;
    unsigned int i;

    /* generate basis vectors v and w */
    dvec_cprod(a, r0, vtmp);
    dvec_scale(1.0/dvec_norm(vtmp), vtmp, v);
    dvec_cprod(a, v, w);

    fp=fopen(fn, "w");
    for (i=0; i<=npts; i++)
    {
        ang=2*3.1415927*i/npts;
        vtmp[0]=r0[0] + rad * (v[0]*cos(ang) + w[0]*sin(ang));
        vtmp[1]=r0[1] + rad * (v[1]*cos(ang) + w[1]*sin(ang));
        vtmp[2]=r0[2] + rad * (v[2]*cos(ang) + w[2]*sin(ang));
        fprintf(fp, "%g %g %g\n", vtmp[0], vtmp[1], vtmp[2]);
    };
    fclose(fp);
}

void
debug_print_fitcylinder(char * fn, int npts, dvec r0, dvec a, double rad, double h1, double h2)
{
    FILE *fp;
    dvec vtmp, v, w;
    double ang;
    unsigned int i;

    /* generate basis vectors v and w */
    dvec_cprod(a, r0, vtmp);
    dvec_scale(1.0/dvec_norm(vtmp), vtmp, v);
    dvec_cprod(a, v, w);

    fp=fopen(fn, "w");
    for (i=0; i<=npts; i++)
    {
        ang=2*3.1415927*i/npts;
        vtmp[0]=r0[0] + h1*a[0] + rad * (v[0]*cos(ang) + w[0]*sin(ang));
        vtmp[1]=r0[1] + h1*a[1] + rad * (v[1]*cos(ang) + w[1]*sin(ang));
        vtmp[2]=r0[2] + h1*a[2] + rad * (v[2]*cos(ang) + w[2]*sin(ang));
        fprintf(fp, "%g %g %g\n", vtmp[0], vtmp[1], vtmp[2]);
    }
    for (i=0; i<=npts; i++)
    {
        ang=2*3.1415927*i/npts;
        vtmp[0]=r0[0] + h2*a[0] + rad * (v[0]*cos(ang) + w[0]*sin(ang));
        vtmp[1]=r0[1] + h2*a[1] + rad * (v[1]*cos(ang) + w[1]*sin(ang));
        vtmp[2]=r0[2] + h2*a[2] + rad * (v[2]*cos(ang) + w[2]*sin(ang));
        fprintf(fp, "%g %g %g\n", vtmp[0], vtmp[1], vtmp[2]);
    }

    /*3 addditional points to give side view in gplot?*/

    fclose(fp);
}

static void calc_helaxis_kahn(const int nx, dvec x[], dvec axis_loc)
{
    //Vector.
    //Kahn method [Kahn, Comput. Chem. 13:185-189 (1989).]
    //Bisect angle between x_j - x_i and x_k - x_j
    dvec xa, xb, xc, xd;
    int i;

    if (nx < 4) {
       fprintf(stderr,"WARNING: less than 4 points given to Helical axis calculation!\n");
       return;
    }

    //dvec_com(nx, x, xcom);
    clear_dvec(axis_loc);
    for(i=0;i<nx-3;i++)
    {
        dvec_sub(x[i+1], x[i], xa);
        dvec_scale(1.0/dvec_norm(xa), xa, xa);
        dvec_sub(x[i+2], x[i+1],xb);
        dvec_scale(1.0/dvec_norm(xb), xb, xb);
        dvec_sub(xb, xa, xc); //V1 bisector
        dvec_sub(x[i+3], x[i+2], xa);
        dvec_scale(1.0/dvec_norm(xa), xa, xa);
        dvec_sub(xa, xb, xd); //V2 bisector
        dvec_cprod(xc, xd, xa); //Estimate of axis.
        dvec_inc(axis_loc, xa);
    }
    //Normalise.
    dvec_scale(1.0/dvec_norm(axis_loc), axis_loc, axis_loc);
}

//Assuming a is normalised.
//Theortically, as everything is in 2D, the resulting r0 should be perpendicular to a at all points.

fit_circle_fixed_a(const gsl_multifit_fdfsolver_type *T, int nx, dvec x[], double sigma[],
                              dvec a, dvec r0, double *rad,
                              int bVerbose)
{
    dvec r0loc, xa;
    double radloc;

    int status;
    unsigned int i, iter = 0, maxiter = MAX_ITER;
    const size_t npts = nx;
    size_t nparams;
    double *x_init;
    struct nlsq_datablock data;
    double th, ph, nu, r0norm;

    nparams=3;

    gsl_multifit_fdfsolver *s;
    gsl_multifit_function_fdf f;
    gsl_vector_view xview;
    gsl_matrix *covar = gsl_matrix_alloc (nparams, nparams);

    f.f = &expb_fcircar;
    f.df = &expb_dfcircar;
    f.fdf = &expb_fdfcircar;

    f.n = npts;
    f.p = nparams;
    f.params = &data; //Reassign contents in a moment.

    //projection of x onto the plane perpendicular to a and through origin.
    dvec *xp;
    //snew(xp, nx);
    xp=malloc(sizeof(double)*3*nx);

    data.n=nx;
    data.x=xp;
    data.sigma=sigma;
    data.a[0]=a[0];
    data.a[1]=a[1];
    data.a[2]=a[2];

    //FILE *fp=fopen("debug-circproj.dat","w");
    for (i=0;i<nx;i++)
    {
        dvec_scale( dvec_iprod(x[i], a), a, xa);
        dvec_sub(x[i], xa, xp[i]);
	    sigma[i]=0.1;
	    //fprintf(fp, "%g %g %g\n", xp[i][0], xp[i][1], xp[i][2]);
    }
    //fclose(fp);
    //Now the set of xp is 2D.

    //Grab initial estimates
    dvec_com(nx, xp, r0loc);
    radloc=dvec_avrad(nx, xp, r0loc);
    //fprintf(stderr,"Guessed r0: %g %g %g\n", r0loc[0], r0loc[1], r0loc[2]);
    //fprintf(stderr,"r0.a: %g\n", dvec_iprod(r0loc, a));

    //Linearise r0loc
    /* dvec_scale(dvec_iprod(r0loc, a), a, xa);
    dvec_sub(r0loc, xa, r0loc);
    fprintf(stderr,"r0loc: %g %g %g\n", r0loc[0], r0loc[1], r0loc[2]);
    fprintf(stderr,"r0loc.a: %g\n", dvec_iprod(r0loc, a)); */

    //Load initial estimates into gsl form
    x_init=malloc(sizeof(double)*nparams);

    r0a_cart_to_polar(r0loc, a, &th, &ph, &nu, &r0norm );
    x_init[0]=nu;
    x_init[1]=r0norm ; //|r0|
    x_init[2]=radloc  ; //radius of cylinder
    //fprintf(stderr,"th phi nu r0n: %g %g %g %g\n", th*180/PI, ph*180/PI, nu*180/PI, r0norm);

    xview = gsl_vector_view_array (x_init, nparams);

    //Prepare solvers,
    s = gsl_multifit_fdfsolver_alloc(T, npts, nparams);
    gsl_multifit_fdfsolver_set (s, &f, &xview.vector);

    if (bVerbose)
        print_state1(iter, s);
    do
    {
        iter++;
        status = gsl_multifit_fdfsolver_iterate (s);
        if (bVerbose)
        {
            printf ("status = %s\n", gsl_strerror (status));
            print_state1(iter, s);
        }

        if (status)
            break;

        status = gsl_multifit_test_delta (s->dx, s->x,
                                        1e-4, 1e-4);
    }
    while (status == GSL_CONTINUE && iter < maxiter);

    gsl_multifit_covar (s->J, 0.0, covar);

    if (bVerbose)
        report_gsl_solver_outcome1(s, covar, npts, nparams);

    //Output
    nu=GSL_FIT(0);
    r0norm=GSL_FIT(1);
    *rad=GSL_FIT(2);

    r0a_polar_to_cart(th, ph, nu, r0norm, r0, xa); //a already known, so throw to trash.
    //fprintf(stderr,"th phi nu r0n: %g %g %g %g\n", th*180/PI, ph*180/PI, nu*180/PI, r0norm);
    //fprintf(stderr,"r0 (circ): %g %g %g\n", r0[0], r0[1], r0[2]);
    //fprintf(stderr,"a (Kahn): %g %g %g\n", a[0], a[1], a[2]);
    //fprintf(stderr,"r0.a: %g\n", dvec_iprod(r0, a));

    gsl_multifit_fdfsolver_free (s);
    gsl_matrix_free (covar);
    //sfree(xp);
    free(xp);
    free(x_init);
}

/*Assuming a is normalised.
 * We will transform into polar coordinates for the internal search
 * This ensures that r.a = 0, |a|=1.
 * a is broken into values of theta and phi.
 * r is broken into anomaly angle nu, and the radius.
 * nu is defined from the ascending node vector n (astronomy), with roperties
 * n.a = 0, n.z= 0 (lies on the x/y plane.)
 * n=-sin(th)*i + cos(th)*j
 * a= cos(th)*cos(ph)*i+ sin(th)*cos(ph)*j + sin(ph)*k
 * Thus, setting r.n=|r|*cos(nu) and r.a=0 gives:
 * r = -sin(nu)*cos(th)*sin(ph) - cos(nu)*sin(th) * i +
 *   = -sin(nu)*sin(th)*sin(ph) + cos(nu)*cos(th) * j +
 *   = -sin(nu)*cos(ph)                           * k .
 *
 * Conversely:
 * nu = acos ( n.r0 / |n||ro| )
 *
 */

fit_cylinder_all(const gsl_multifit_fdfsolver_type *T, int nx, dvec x[], double sigma[],
                         dvec a, dvec r0, double *rad,
                         int bVerbose)
{

    double th, ph, nu, r0norm ;

    int status;
    unsigned int iter = 0, maxiter = MAX_ITER;
    const size_t npts = nx;
    size_t nparams;
    double *x_init;
    struct nlsq_datablock data = {0, NULL, NULL};

    nparams=5;

    gsl_multifit_fdfsolver *s;
    gsl_multifit_function_fdf f;
    gsl_vector_view xview;
    gsl_matrix *covar = gsl_matrix_alloc (nparams, nparams);

    f.f = &expb_fcylr;
    f.df = &expb_dfcylr;
   	f.fdf = &expb_fdfcylr;

    f.n = npts;
    f.p = nparams;
    f.params = &data; //Reassign contents in a moment.

    data.n=nx;
    data.x=x; //Presumable safe from manipulation.
    data.sigma=sigma;

    x_init=malloc(sizeof(double)*nparams);

    //Grab initial estimates, converting from Cartesian into angular form.
    r0a_cart_to_polar(r0, a, &th, &ph, &nu, &r0norm );

    //Load initial estimates into gsl form
    x_init[0]=th;
    x_init[1]=ph;
    x_init[2]=nu;
    x_init[3]=r0norm ; //|r0|
    x_init[4]=*rad  ; //radius of cylinder

    xview = gsl_vector_view_array (x_init, nparams);

    //Prepare solvers,
    s = gsl_multifit_fdfsolver_alloc(T, npts, nparams);
    gsl_multifit_fdfsolver_set (s, &f, &xview.vector);

    if (bVerbose)
        print_state2(iter, s);
    do
    {
        iter++;
        status = gsl_multifit_fdfsolver_iterate (s);
        if (bVerbose)
        {
            printf ("status = %s\n", gsl_strerror (status));
            print_state2(iter, s);
        }

        if (status)
            break;

        status = gsl_multifit_test_delta (s->dx, s->x,
                                        1e-4, 1e-4);
    }
    while (status == GSL_CONTINUE && iter < maxiter);

    gsl_multifit_covar (s->J, 0.0, covar);

    if (bVerbose)
        report_gsl_solver_outcome2(s, covar, npts, nparams);

    //Output, convert back into Cartesian representation.
    th=GSL_FIT(0);
    ph=GSL_FIT(1);
    nu=GSL_FIT(2);
    r0norm=GSL_FIT(3);
    *rad=GSL_FIT(4);

    r0a_polar_to_cart(th, ph, nu, r0norm, r0,  a);

    /*
    a[0]=cos(th)*cos(ph);
    a[1]=sin(th)*cos(ph);
    a[2]=sin(ph);
    r0[0]= r0norm*(-1*sin(nu)*cos(th)*sin(ph)-cos(nu)*sin(th));
    r0[1]= r0norm*(-1*sin(nu)*sin(th)*sin(ph)+cos(nu)*cos(th));
   	r0[2]= r0norm*sin(nu)*cos(ph);*/

    gsl_multifit_fdfsolver_free(s);
    gsl_matrix_free (covar);
    free(x_init);
}

/* The controlling function, used to minimise outer fuss.
 * Allows the options of NULL in the solver and weight function variables.
 * Catches these and creates a local, default copy.
 * The return values are a, r0, rad. */
void
fit_cylinder(const gsl_multifit_fdfsolver_type *T, int nx, dvec x[], double sigma[],
                         dvec a, dvec r0, double *rad,
                         int bVerbose)
{
    const gsl_multifit_fdfsolver_type *Tloc;
    double *sigloc;
    int bSig, i;

    if( T == NULL)
        Tloc = gsl_multifit_fdfsolver_lmsder;
    else
        Tloc = T;

    if(sigma == NULL)
    {
        bSig=1;
        //snew(sigloc, nx);
        sigloc=malloc(sizeof(double)*nx);
        for(i=0; i<nx; i++)
            sigloc[i]=0.1;
    }
    else
    {
        bSig=0;
        sigloc=sigma;
    }

    /* Begin fitting process. */
    /* Get estimate of a */
    calc_helaxis_kahn(nx, x, a);

    /* Using fixed a, get estimate of r0 and rad */
    fit_circle_fixed_a(Tloc, nx, x, sigloc, a, r0, rad, bVerbose);

    /* Optimise r0, a, and rad together */
    fit_cylinder_all(Tloc, nx, x, sigloc, a, r0, rad, bVerbose);

    if (bSig && sigloc)
        free(sigloc);
}

/* Given a cylinder, calculate average rise and turn per atom.
 */
calc_avg_rise_turn_fixed_cylinder(int nx, dvec x[],
                    dvec a, dvec r0, double *rad,
                    double *avrise, double *avturn, double *rise0, double *turn0)
{
    int i;

    double h, om;
    double dhsum=0, dosum=0, hlast=0, omlast=0, tmp=0;
    dvec v, w;

    /*Determine v and w */
    r0a_calc_vw(r0, a, v, w);

    for(i=0; i<nx; i++)
    {
        calc_cylinder_rise_turn(x[i], r0, a, v, w, &h, &om, NULL);
        if (i>0)
        {
            dhsum += h-hlast;
            tmp   = om-omlast;
            dosum += (tmp > PI) ? tmp-2*PI : ( (tmp < -PI ) ? tmp+2*PI : tmp ) ;
        }
        else if(i==0)
        {
            *rise0=h;
            *turn0=om;
        }
         hlast=h;
         omlast=om;
    }
    dhsum/=(nx-1);
    dosum/=(nx-1);

    *avrise=dhsum;
    *avturn=dosum;
}

/* The external function for fitting helices, which calls fit_cylinder as well.
 */
void
fit_helix_simple(const gsl_multifit_fdfsolver_type *T, int nx, dvec x[], double sigma[],
                      dvec a, dvec r0, double *rad,
                      double *avrise, double *avturn, double *h0, double *t0,
                      int bVerbose)
{
    const gsl_multifit_fdfsolver_type *Tloc;
    double *sigloc;
    int bSig, i;

    if( T == NULL)
        Tloc = gsl_multifit_fdfsolver_lmsder;
    else
        Tloc = T;

    if(sigma == NULL)
    {
        bSig=1;
        //snew(sigloc, nx);
        sigloc=malloc(sizeof(double)*nx);
        for(i=0; i<nx; i++)
            sigloc[i]=0.1;
    }
    else
    {
        bSig=0;
        sigloc=sigma;
    }

    /* Fit the initial cylinder */
    fit_cylinder(Tloc, nx, x, sigloc, a, r0, rad, bVerbose);

    /* Test the expected fit? */

    /* Estimate the helical parameters from fitted cylinder. */
    calc_avg_rise_turn_fixed_cylinder(nx, x, a, r0, rad,
                                     avrise, avturn, h0, t0);

    /* Full fitting? */
    /* fit_helix_all(Tloc, nx, x, sigloc,
              a, r0, rad, hpitch, pitch0, hturn, omega0);*/

    if (bSig && sigloc)
        free(sigloc);
}
