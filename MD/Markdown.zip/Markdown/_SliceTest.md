
------------DZ0--------------------------

# h1-h3测试

## h2

### h3


---1----------------

# ol测试

使用方法

1. 运行代码: `run PESdemo.py`
2. 背景设为白色: `bg white`
3. 设定光线追踪: `set ray_trace_frames=1`
4. 输出png图片: `mpng PESdemo`

---1------

# ul测试

* gif 最常用的, 大家也最熟悉. 

	- 各种软件支持最好, 算是通用格式. 
	- 可惜只有256色, 失真有时很严重, 特别是对光线追踪渲染过的图片.

* apng 基于png的动画图片, 效果等同于png. 可惜目前支持不广, 尚未得到png官方承认.


-----2-------

# 链接测试
`
更具体的信息可参考下面的网文:

1. [小牛犊APNG力挫老古董MNG](http://blog.csdn.net/dj0379/article/details/7462578)
2. [APNG编辑制作工具](http://hi.baidu.com/mudyoxorikbcdmd/item/1cd7a68f1d23642a110ef309)

---4-----

# 引用测试

>Think like a man of action, act like a man of thought.
>
>― Henri Bergson


------3-----------------

# 公式测试

欧拉公式, $e^{i \pi}+1=0$

薛定谔方程 $\hat H \Y = -i \hbar {\partial \Y \over \partial t}$

圆的参数方程

 $\begin{align}
x &= \sin t \\
y &= \cos t
\end{align}

---6-----

# 图片测试

![图片](http://placekitten.com/g/800/600)


----3----

# 视频测试

![Let It Go](http://player.youku.com/embed/XNjcyMDU4Njg0)

Idina Menze和Caleb Hyles激情对唱Let It Go：
<iframe height=400 width=500 src="http://player.youku.com/embed/XNjcyMDU4Njg0" frameborder=0 allowfullscreen></iframe>


----3----

# 视频测试

![视频](http://videos-cdn.mozilla.net/brand/Mozilla_Firefox_Manifesto_v0.2_640.webm)

<video src="http://videos-cdn.mozilla.net/brand/Mozilla_Firefox_Manifesto_v0.2_640.webm" poster="http://www.mozilla.org/images/about/poster.jpg"></video>


----2------

# 表格测试

|             |          Grouping           ||
First Header  | Second Header | Third Header |
------------- | :-----------: | ------------:|
Content       |          *Long Cell*        ||
Content       |   **Cell**    |         Cell |

New section   |     More      |         Data |
And more      | With an escaped '\|'         ||

-------1-----------------------------

# ChemDoodle测试

```XYZ tiny
	28
	DDT
	Cl    0.0456    1.0544   -1.9374
	Cl   -0.7952   -1.7026   -1.7706
	Cl    0.6447   -0.8006   -4.1065
	Cl    1.8316   -0.9435    4.4004
	Cl    6.9949    1.1239   -3.9007
	C     1.9032   -1.0692   -1.6001
	C     1.8846   -1.0376   -0.1090
	C     3.2176   -0.5035   -2.1949
	C     0.5585   -0.6223   -2.3126
	C     2.2670    0.1198    0.5688
	C     4.3480   -1.2638   -2.0859
	C     1.4856   -2.1660    0.6075
	C     3.1719    0.7242   -2.7939
	C     2.2506    0.1490    1.9633
	C     5.5313   -0.7541   -2.6203
	C     1.4691   -2.1369    2.0020
	C     4.3552    1.2340   -3.3284
	C     1.8515   -0.9793    2.6800
	C     5.5350    0.4948   -3.2417
	H     1.9777   -2.1366   -1.8749
	H     2.5727    1.0177    0.0401
	H     4.3513   -2.2356   -1.6034
	H     1.1951   -3.0814    0.0991
	H     2.3077    1.3562   -2.8879
	H     2.5491    1.0585    2.4783
	H     6.4431   -1.3411   -2.5451
	H     1.1584   -3.0244    2.5473
	H     4.3449    2.2098   -3.8075
```

----------------3----------------------

```XYZ sli
C:\Users\Jicun\F_Prg\Markdown\Chem.xyz
```


-----4------

```cIF lit
C:\Users\Jicun\F_Prg\Markdown\Chem.cif
```

-------------5-----------------------------------


```pDB lit
C:\Users\Jicun\F_Prg\Markdown\Chem.pdb
```
