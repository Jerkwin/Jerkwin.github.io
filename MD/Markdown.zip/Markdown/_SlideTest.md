------------DZ0--------------------------

# 基于markdown和DZslide的网页幻灯片

## Jerkwin

### 2015-01-12 11:17:03

-----1------

# 为什么使用这种方法?

- 文本格式, 便于传播
- 关注内容, 格式统一
- 图片, 视频, 代码插入方便
- ......

---2---

# 使用方法

1. 编辑markdown文本
2. 一键编译为HTML文件
3. 观看

---1------

# 使用引用

>Think like a man of action, act like a man of thought.
>
>― Henri Bergson

---3---

# 使用链接

更具体的信息可参考下面的网文:

1. [小牛犊APNG力挫老古董MNG](http://blog.csdn.net/dj0379/article/details/7462578)
2. [APNG编辑制作工具](http://hi.baidu.com/mudyoxorikbcdmd/item/1cd7a68f1d23642a110ef309)

------3-----------------

# 使用MathJax公式

欧拉公式, $e^{i \pi}+1=0$

薛定谔方程 $\hat H \Y = -i \hbar {\partial \Y \over \partial t}$

圆的参数方程

$\begin{align}
x &= \sin t \\
y &= \cos t
\end{align}$

---6-----

# 使用图片

![图片](http://placekitten.com/g/800/600)


----3----

# 使用视频

![Let It Go](http://player.youku.com/embed/XNjcyMDU4Njg0)

Idina Menze和Caleb Hyles激情对唱Let It Go：
<iframe height=400 width=500 src="http://player.youku.com/embed/XNjcyMDU4Njg0" frameborder=0 allowfullscreen></iframe>


----3----

# 使用视频: 另一种方式

![视频](http://videos-cdn.mozilla.net/brand/Mozilla_Firefox_Manifesto_v0.2_640.webm)

<video src="http://videos-cdn.mozilla.net/brand/Mozilla_Firefox_Manifesto_v0.2_640.webm" poster="http://www.mozilla.org/images/about/poster.jpg"></video>

----2------

# 使用表格

|             |          Grouping           ||
First Header  | Second Header | Third Header |
------------- | :-----------: | ------------:|
Content       |          *Long Cell*        ||
Content       |   **Cell**    |         Cell |

New section   |     More      |         Data |
And more      | With an escaped '\|'         ||

-------1-----------------------------

# 利用gnuplot作图

- 函数作图

```gPL
	set xl"x"; set yl"y"
	plot sin(x)
```

---1----

- 直接数据作图

```gPL
	$Mydata << EOD
	      1 2 3
	      2 5 6
	      3 8 9
EOD
	plot $Mydata u 1:2 w p ps 4, $Mydata u 1:3 w lp ps 4 lw 4
```

---2---

- 文件数据作图

```gPL
	set xl"r(\305)"; set yl"g(r)"
	plot '_Test.dat' u 1:2 w l lw 4
```

---2---

# 基于ditaa的ASCII图

```ASC
	+--------+   +-------+    +-------+
	|        | --+ ditaa +--> |       |
	|  Text  |   +-------+    |diagram|
	|Document|   |!magic!|    |       |
	|     {d}|   |       |    | cRED  |
	+---+----+   +-------+    +-------+
	    :                         ^
	    |       Lots of work      |
	    +-------------------------+
```

---1----

# 基于ChemDoodle的3D分子构型

### XYZ格式数据

```XYZ tiny
	28
	DDT
	Cl    0.0456    1.0544   -1.9374
	Cl   -0.7952   -1.7026   -1.7706
	Cl    0.6447   -0.8006   -4.1065
	Cl    1.8316   -0.9435    4.4004
	Cl    6.9949    1.1239   -3.9007
	C     1.9032   -1.0692   -1.6001
	C     1.8846   -1.0376   -0.1090
	C     3.2176   -0.5035   -2.1949
	C     0.5585   -0.6223   -2.3126
	C     2.2670    0.1198    0.5688
	C     4.3480   -1.2638   -2.0859
	C     1.4856   -2.1660    0.6075
	C     3.1719    0.7242   -2.7939
	C     2.2506    0.1490    1.9633
	C     5.5313   -0.7541   -2.6203
	C     1.4691   -2.1369    2.0020
	C     4.3552    1.2340   -3.3284
	C     1.8515   -0.9793    2.6800
	C     5.5350    0.4948   -3.2417
	H     1.9777   -2.1366   -1.8749
	H     2.5727    1.0177    0.0401
	H     4.3513   -2.2356   -1.6034
	H     1.1951   -3.0814    0.0991
	H     2.3077    1.3562   -2.8879
	H     2.5491    1.0585    2.4783
	H     6.4431   -1.3411   -2.5451
	H     1.1584   -3.0244    2.5473
	H     4.3449    2.2098   -3.8075
```

----------------3----------------------

### XYZ格式的动画文件

```XYZ sli
Chem.xyz
```

-------------5-----------------------------------

### PDB格式的文件

```pDB lit
Chem.pdb
```
-----4------

### CIF格式的文件

```cIF lit
Chem.cif
```

